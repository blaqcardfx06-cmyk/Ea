package com.blaqcard.eacloud.network

import kotlinx.serialization.json.Json
import okhttp3.Interceptor
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Response
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory

/**
 * Adds the two headers every Deriv REST endpoint in schemas/ requires:
 * `Deriv-App-ID` and `Authorization: Bearer <token>`. Values are read live
 * from [credentials] on every request, so updating settings takes effect
 * immediately without rebuilding the client.
 */
class AuthInterceptor(private val credentials: DerivCredentials) : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val builder = chain.request().newBuilder()
        credentials.appId?.takeIf { it.isNotBlank() }?.let {
            builder.addHeader("Deriv-App-ID", it)
        }
        credentials.authToken?.takeIf { it.isNotBlank() }?.let {
            builder.addHeader("Authorization", "Bearer $it")
        }
        return chain.proceed(builder.build())
    }
}

/** Simple in-memory snapshot of the credentials, refreshed from CredentialsStore. */
data class DerivCredentials(
    val baseUrl: String,
    val appId: String?,
    val authToken: String?
)

object NetworkModule {

    private val json = Json {
        ignoreUnknownKeys = true
        isLenient = true
        explicitNulls = false
    }

    /**
     * Builds a fresh [DerivApi] pointed at [credentials.baseUrl]. Retrofit's
     * base URL is fixed per-instance, so we rebuild when the user changes the
     * base URL in Settings rather than trying to mutate a shared client.
     */
    fun buildApi(credentials: DerivCredentials): DerivApi {
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        }
        val client = OkHttpClient.Builder()
            .addInterceptor(AuthInterceptor(credentials))
            .addInterceptor(logging)
            .build()

        val contentType = "application/json".toMediaType()
        val normalizedBaseUrl =
            if (credentials.baseUrl.endsWith("/")) credentials.baseUrl else "${credentials.baseUrl}/"

        val retrofit = Retrofit.Builder()
            .baseUrl(normalizedBaseUrl)
            .client(client)
            .addConverterFactory(json.asConverterFactory(contentType))
            .build()

        return retrofit.create(DerivApi::class.java)
    }
}

package com.blaqcard.eacloud.data

import com.blaqcard.eacloud.network.ApiErrorResponse
import com.blaqcard.eacloud.network.DerivCredentials
import com.blaqcard.eacloud.network.NetworkModule
import com.blaqcard.eacloud.network.OptionsAccount
import com.blaqcard.eacloud.network.Wallet
import kotlinx.serialization.json.Json
import retrofit2.Response

data class AccountOverview(
    val nickname: String?,
    val accounts: List<OptionsAccount>,
    val wallets: List<Wallet>
)

sealed class ApiResult<out T> {
    data class Success<T>(val value: T) : ApiResult<T>()
    data class Failure(val message: String) : ApiResult<Nothing>()
}

class DerivRepository(private val credentialsStore: CredentialsStore) {

    private val errorJson = Json { ignoreUnknownKeys = true }

    /** Fetches accounts, wallets, and nickname in one shot for the Account screen. */
    suspend fun loadAccountOverview(): ApiResult<AccountOverview> {
        val creds = credentialsStore.current()
        if (creds.baseUrl.isBlank() || creds.appId.isNullOrBlank() || creds.authToken.isNullOrBlank()) {
            return ApiResult.Failure("Not connected. Add your Deriv API base URL, App ID, and access token in Settings.")
        }

        val api = NetworkModule.buildApi(creds)

        val accountsResp = api.getAccounts()
        if (!accountsResp.isSuccessful) {
            return ApiResult.Failure(describeError(accountsResp, creds))
        }

        val walletsResp = api.getWallets()
        if (!walletsResp.isSuccessful) {
            return ApiResult.Failure(describeError(walletsResp, creds))
        }

        // Nickname is best-effort — don't fail the whole screen if it 404s.
        val nickname = runCatching {
            val resp = api.getNickname()
            if (resp.isSuccessful) resp.body()?.data?.nickname else null
        }.getOrNull()

        return ApiResult.Success(
            AccountOverview(
                nickname = nickname,
                accounts = accountsResp.body()?.data.orEmpty(),
                wallets = walletsResp.body()?.data.orEmpty()
            )
        )
    }

    private fun describeError(resp: Response<*>, @Suppress("UNUSED_PARAMETER") creds: DerivCredentials): String {
        val raw = runCatching { resp.errorBody()?.string() }.getOrNull()
        val parsed = raw?.let { runCatching { errorJson.decodeFromString(ApiErrorResponse.serializer(), it) }.getOrNull() }
        val first = parsed?.errors?.firstOrNull()
        return when {
            first?.message != null -> first.message
            resp.code() == 401 -> "Unauthorized — check your access token."
            resp.code() == 403 -> "Access denied for this token/app."
            resp.code() == 404 -> "Endpoint not found — check the base URL."
            else -> "Request failed (HTTP ${resp.code()})."
        }
    }
}

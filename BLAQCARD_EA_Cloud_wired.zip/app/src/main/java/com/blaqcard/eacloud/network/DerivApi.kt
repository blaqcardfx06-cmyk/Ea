package com.blaqcard.eacloud.network

import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query

/**
 * REST surface used by the Account screen. Auth (Authorization + Deriv-App-ID
 * headers) is injected by [AuthInterceptor] rather than declared per-method,
 * since every one of these calls requires the same two headers.
 */
interface DerivApi {

    @GET("trading/v1/options/accounts")
    suspend fun getAccounts(): Response<GetAccountsResponse>

    @GET("wallet/v1/wallets")
    suspend fun getWallets(
        @Query("conversion_currency") conversionCurrency: String? = null
    ): Response<WalletListResponse>

    @GET("account/v1/nickname")
    suspend fun getNickname(): Response<AccountNicknameResponse>
}

package com.blaqcard.eacloud.network

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Data models mirroring the JSON Schemas shipped in schemas/ for the
 * Deriv "Third Party API" (see schemas/rest-api-openapi.json).
 *
 * Only the REST, non-WebSocket endpoints needed for the Account / Balance /
 * Wallet screens are modeled here:
 *   GET /trading/v1/options/accounts   -> get_accounts_response.schema.json
 *   GET /wallet/v1/wallets             -> wallet_list_response.schema.json
 *   GET /account/v1/nickname           -> account_nickname_response.schema.json
 *
 * EA start/stop/list is intentionally NOT wired to Deriv's auto_start/auto_stop
 * endpoints — those model Deriv's own synthetic-strategy runs, not real MT4/MT5
 * Expert Advisors. That stays a stub for a future MT4/5 bridge (see
 * ui/EaBridgeStub.kt).
 */

// ---- GET /trading/v1/options/accounts ----

@Serializable
data class OptionsAccount(
    @SerialName("account_id") val accountId: String,
    val balance: Double,
    val currency: String,
    val group: String,
    val status: String, // "active" | "inactive"
    @SerialName("account_type") val accountType: String // "demo" | "real"
)

@Serializable
data class ApiMetadata(
    val endpoint: String? = null,
    val method: String? = null,
    val timing: Double? = null
)

@Serializable
data class GetAccountsResponse(
    val data: List<OptionsAccount> = emptyList(),
    val meta: ApiMetadata? = null
)

// ---- GET /wallet/v1/wallets ----

@Serializable
data class WalletCurrencyBalance(
    val balance: String,
    val input: String,
    val output: String
)

@Serializable
data class WalletTotalBalance(
    @SerialName("converted_to") val convertedTo: String,
    @SerialName("approximate_total_balance") val approximateTotalBalance: String,
    @SerialName("approximate_total_input") val approximateTotalInput: String,
    @SerialName("approximate_total_output") val approximateTotalOutput: String
)

@Serializable
data class Wallet(
    @SerialName("wallet_id") val walletId: String,
    val type: String,
    val balances: Map<String, WalletCurrencyBalance> = emptyMap(),
    @SerialName("total_balance") val totalBalance: WalletTotalBalance? = null
)

@Serializable
data class WalletListResponse(
    val data: List<Wallet> = emptyList()
)

// ---- GET /account/v1/nickname ----

@Serializable
data class NicknameData(
    @SerialName("external_reference_id") val externalReferenceId: String,
    val nickname: String
)

@Serializable
data class AccountNicknameResponse(
    val data: NicknameData? = null,
    val errors: List<ApiErrorEntry> = emptyList(),
    val metadata: ApiMetadata? = null
)

// ---- Shared error envelope (components/schemas/Error in rest-api-openapi.json) ----

@Serializable
data class ApiErrorEntry(
    val status: Int = 400,
    val code: String? = null,
    val message: String? = null,
    val field: String? = null
)

@Serializable
data class ApiErrorResponse(
    val errors: List<ApiErrorEntry> = emptyList(),
    val meta: ApiMetadata? = null
)

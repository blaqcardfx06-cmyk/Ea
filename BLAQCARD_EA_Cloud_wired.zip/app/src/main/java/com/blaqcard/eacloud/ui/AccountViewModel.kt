package com.blaqcard.eacloud.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.blaqcard.eacloud.data.AccountOverview
import com.blaqcard.eacloud.data.ApiResult
import com.blaqcard.eacloud.data.CredentialsStore
import com.blaqcard.eacloud.data.DerivRepository
import com.blaqcard.eacloud.network.DerivCredentials
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed class AccountUiState {
    data object NotConnected : AccountUiState()
    data object Loading : AccountUiState()
    data class Loaded(val overview: AccountOverview) : AccountUiState()
    data class Error(val message: String) : AccountUiState()
}

class AccountViewModel(
    private val credentialsStore: CredentialsStore,
    private val repository: DerivRepository = DerivRepository(credentialsStore)
) : ViewModel() {

    private val _uiState = MutableStateFlow<AccountUiState>(AccountUiState.NotConnected)
    val uiState: StateFlow<AccountUiState> = _uiState.asStateFlow()

    private val _credentials = MutableStateFlow(DerivCredentials("", null, null))
    val credentials: StateFlow<DerivCredentials> = _credentials.asStateFlow()

    init {
        viewModelScope.launch {
            val saved = credentialsStore.current()
            _credentials.value = saved
            if (saved.baseUrl.isNotBlank() && !saved.appId.isNullOrBlank() && !saved.authToken.isNullOrBlank()) {
                refresh()
            }
        }
    }

    fun saveConnection(baseUrl: String, appId: String, authToken: String) {
        viewModelScope.launch {
            credentialsStore.save(baseUrl, appId, authToken)
            _credentials.value = credentialsStore.current()
            refresh()
        }
    }

    fun refresh() {
        viewModelScope.launch {
            _uiState.value = AccountUiState.Loading
            when (val result = repository.loadAccountOverview()) {
                is ApiResult.Success -> _uiState.value = AccountUiState.Loaded(result.value)
                is ApiResult.Failure -> _uiState.value = AccountUiState.Error(result.message)
            }
        }
    }

    fun disconnect() {
        viewModelScope.launch {
            credentialsStore.clear()
            _credentials.value = DerivCredentials("", null, null)
            _uiState.value = AccountUiState.NotConnected
        }
    }
}

package com.blaqcard.eacloud.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.blaqcard.eacloud.network.OptionsAccount
import com.blaqcard.eacloud.network.Wallet

private val Bg = Color(0xFF080A0F)
private val Card = Color(0xFF11151D)
private val Accent = Color(0xFFFFC107)
private val Green = Color(0xFF29D17D)

data class EA(val name:String, val platform:String, var running:Boolean, val server:String, val latency:Int)

@Composable
fun BlaqcardApp() {
    var tab by remember { mutableStateOf("Home") }
    var eas by remember { mutableStateOf(listOf(
        EA("XAUUSD SNIPER", "MT5", true, "Frankfurt", 12),
        EA("BLAQCARD SMC V4", "MT5", false, "London", 18)
    )) }
    var showAdd by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(containerColor = Card) {
                listOf("Home","EAs","VPS","Account").forEach { item ->
                    NavigationBarItem(selected=tab==item,onClick={tab=item},
                        icon={Text(if(item=="Home")"⌂" else if(item=="EAs")"🤖" else if(item=="VPS")"☁" else"●")},
                        label={Text(item)})
                }
            }
        }
    ) { pad ->
        when(tab) {
            "Home" -> HomeScreen(Modifier.padding(pad), eas, {showAdd=true}, {index ->
                eas = eas.mapIndexed { i,e -> if(i==index) e.copy(running=!e.running) else e }
            })
            "EAs" -> EAListScreen(Modifier.padding(pad), eas, {showAdd=true}, {index ->
                eas = eas.mapIndexed { i,e -> if(i==index) e.copy(running=!e.running) else e }
            })
            "VPS" -> VPSScreen(Modifier.padding(pad))
            else -> AccountScreen(Modifier.padding(pad))
        }
    }
    if(showAdd) AddEADialog({showAdd=false}) { name, platform ->
        eas = eas + EA(name, platform, false, "Frankfurt", 14)
        showAdd=false
    }
}

@Composable
fun Header() {
    Row(Modifier.fillMaxWidth().padding(bottom=18.dp), verticalAlignment=Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("BLAQCARD", color=Accent, fontSize=23.sp, fontWeight=FontWeight.Black)
            Text("EA CLOUD", color=Color.White, fontSize=12.sp, fontWeight=FontWeight.Bold)
        }
        Text("⋮", color=Color.White, fontSize=28.sp)
    }
}

@Composable
fun HomeScreen(mod:Modifier, eas:List<EA>, add:()->Unit, toggle:(Int)->Unit) {
    LazyColumn(mod.fillMaxSize().padding(horizontal=18.dp), contentPadding=PaddingValues(top=22.dp,bottom=30.dp), verticalArrangement=Arrangement.spacedBy(14.dp)) {
        item { Header() }
        item { Text("Good to see you 👋", color=Color.White, fontSize=24.sp, fontWeight=FontWeight.Bold) }
        item {
            Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                Stat("BALANCE","$10,250.40"); Stat("EQUITY","$10,410.20"); Stat("PROFIT","+159.80")
            }
        }
        item { SectionTitle("MY EXPERT ADVISORS") }
        items(eas.withIndex().toList()) { (i,e) -> EACard(e, {toggle(i)}) }
        item { Button(onClick=add, modifier=Modifier.fillMaxWidth().height(52.dp), colors=ButtonDefaults.buttonColors(containerColor=Accent), shape=RoundedCornerShape(14.dp)) { Text("+  ADD EA", color=Color.Black, fontWeight=FontWeight.Bold) } }
    }
}

@Composable
fun EAListScreen(mod:Modifier,eas:List<EA>,add:()->Unit,toggle:(Int)->Unit) {
    LazyColumn(mod.fillMaxSize().padding(18.dp), contentPadding=PaddingValues(bottom=30.dp), verticalArrangement=Arrangement.spacedBy(14.dp)) {
        item { Header(); Text("Expert Advisors",color=Color.White,fontSize=26.sp,fontWeight=FontWeight.Bold) }
        items(eas.withIndex().toList()) { (i,e) -> EACard(e,{toggle(i)}) }
        item { OutlinedButton(onClick=add,modifier=Modifier.fillMaxWidth().height(52.dp)) { Text("+ ADD EXPERT ADVISOR") } }
    }
}

@Composable fun EACard(e:EA,toggle:()->Unit) {
    Card(colors=CardDefaults.cardColors(containerColor=Card),shape=RoundedCornerShape(18.dp),modifier=Modifier.fillMaxWidth()) {
        Column(Modifier.padding(17.dp)) {
            Row(verticalAlignment=Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(e.name,color=Color.White,fontWeight=FontWeight.Bold,fontSize=17.sp)
                    Text("${e.platform}  •  ${e.server}",color=Color.Gray,fontSize=12.sp)
                }
                Text(if(e.running)"● RUNNING" else "● STOPPED",color=if(e.running)Green else Color.Gray,fontSize=12.sp,fontWeight=FontWeight.Bold)
            }
            Spacer(Modifier.height(12.dp))
            Text("VPS latency  ${e.latency} ms    •    24/7 monitoring",color=Color.Gray,fontSize=12.sp)
            Spacer(Modifier.height(12.dp))
            Button(onClick=toggle,modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=if(e.running)Color(0xFF252B35) else Accent)) {
                Text(if(e.running)"STOP EA" else "START EA",color=if(e.running)Color.White else Color.Black,fontWeight=FontWeight.Bold)
            }
        }
    }
}
@Composable fun Stat(title:String,value:String) {
    Card(colors=CardDefaults.cardColors(containerColor=Card),modifier=Modifier.weight(1f),shape=RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(12.dp)) { Text(title,color=Color.Gray,fontSize=10.sp); Spacer(Modifier.height(5.dp)); Text(value,color=Color.White,fontSize=16.sp,fontWeight=FontWeight.Bold) }
    }
}
@Composable fun SectionTitle(t:String){Text(t,color=Color.Gray,fontSize=12.sp,fontWeight=FontWeight.Bold)}
@Composable fun VPSScreen(mod:Modifier) {
    Column(mod.fillMaxSize().padding(18.dp)) { Header(); Text("VPS SERVER",color=Color.Gray); Spacer(Modifier.height(10.dp)); Card(colors=CardDefaults.cardColors(containerColor=Card),shape=RoundedCornerShape(18.dp)) { Column(Modifier.padding(18.dp)) { Text("Frankfurt • VPS-01",color=Color.White,fontWeight=FontWeight.Bold,fontSize=18.sp); Text("● ONLINE",color=Green,fontSize=12.sp); Spacer(Modifier.height(18.dp)); Text("CPU     67%",color=Color.White); Text("RAM     51%",color=Color.White); Text("Network 12 ms",color=Color.White) } } }
}
/**
 * Real Deriv-backed Account screen. Loads accounts + wallets + nickname via
 * [AccountViewModel] -> [com.blaqcard.eacloud.data.DerivRepository] -> the
 * REST endpoints described in schemas/rest-api-openapi.json. EA/VPS tabs are
 * untouched and remain local-only mock state for now.
 */
@Composable
fun AccountScreen(mod: Modifier) {
    val context = LocalContext.current
    val vm: AccountViewModel = viewModel(factory = AccountViewModelFactory(context))
    val state by vm.uiState.collectAsState()
    val creds by vm.credentials.collectAsState()
    var editingConnection by remember { mutableStateOf(false) }

    Column(mod.fillMaxSize().padding(18.dp)) {
        Header()
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("ACCOUNT", color = Color.Gray, fontSize = 12.sp)
                Text("BLAQCARD Trader", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            }
            if (state !is AccountUiState.NotConnected) {
                TextButton(onClick = { editingConnection = true }) { Text("EDIT", color = Accent) }
            }
        }
        Spacer(Modifier.height(18.dp))

        when (val s = state) {
            is AccountUiState.NotConnected -> ConnectDerivCard { editingConnection = true }
            is AccountUiState.Loading -> Box(Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Accent)
            }
            is AccountUiState.Error -> ErrorCard(s.message, onRetry = { vm.refresh() }, onEdit = { editingConnection = true })
            is AccountUiState.Loaded -> AccountOverviewContent(s.overview, onRefresh = { vm.refresh() })
        }
    }

    if (editingConnection) {
        ConnectionDialog(
            initialBaseUrl = creds.baseUrl,
            initialAppId = creds.appId.orEmpty(),
            initialToken = creds.authToken.orEmpty(),
            onDismiss = { editingConnection = false },
            onSave = { baseUrl, appId, token ->
                vm.saveConnection(baseUrl, appId, token)
                editingConnection = false
            },
            onDisconnect = {
                vm.disconnect()
                editingConnection = false
            }
        )
    }
}

@Composable
private fun ConnectDerivCard(onConnect: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Card), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp)) {
            Text("CONNECT YOUR DERIV ACCOUNT", color = Color.Gray, fontSize = 11.sp)
            Spacer(Modifier.height(8.dp))
            Text(
                "Link your Deriv API base URL, App ID, and access token to pull real account balances and wallets.",
                color = Color.White, fontSize = 13.sp
            )
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = onConnect,
                modifier = Modifier.fillMaxWidth().height(48.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Accent),
                shape = RoundedCornerShape(12.dp)
            ) { Text("CONNECT", color = Color.Black, fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
private fun ErrorCard(message: String, onRetry: () -> Unit, onEdit: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Card), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp)) {
            Text("COULDN'T LOAD ACCOUNT", color = Color(0xFFE05252), fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text(message, color = Color.White, fontSize = 13.sp)
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = onRetry) { Text("RETRY") }
                OutlinedButton(onClick = onEdit) { Text("EDIT CONNECTION") }
            }
        }
    }
}

@Composable
private fun AccountOverviewContent(overview: com.blaqcard.eacloud.data.AccountOverview, onRefresh: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(14.dp), contentPadding = PaddingValues(bottom = 30.dp)) {
        item {
            overview.nickname?.let {
                Text(it, color = Accent, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
            }
        }
        item { SectionTitle("TRADING ACCOUNTS") }
        if (overview.accounts.isEmpty()) {
            item { Text("No accounts returned for this token.", color = Color.Gray, fontSize = 13.sp) }
        }
        items(overview.accounts) { acc -> AccountCard(acc) }

        item { Spacer(Modifier.height(4.dp)); SectionTitle("WALLETS") }
        if (overview.wallets.isEmpty()) {
            item { Text("No wallets returned for this token.", color = Color.Gray, fontSize = 13.sp) }
        }
        items(overview.wallets) { w -> WalletCard(w) }

        item {
            Spacer(Modifier.height(6.dp))
            OutlinedButton(onClick = onRefresh, modifier = Modifier.fillMaxWidth()) { Text("REFRESH") }
        }
    }
}

@Composable
private fun AccountCard(acc: OptionsAccount) {
    Card(colors = CardDefaults.cardColors(containerColor = Card), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(acc.accountId, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text("${acc.accountType.uppercase()}  •  ${acc.group}", color = Color.Gray, fontSize = 12.sp)
                }
                Text(
                    if (acc.status == "active") "● ACTIVE" else "● INACTIVE",
                    color = if (acc.status == "active") Green else Color.Gray,
                    fontSize = 11.sp, fontWeight = FontWeight.Bold
                )
            }
            Spacer(Modifier.height(10.dp))
            Text("${acc.balance} ${acc.currency}", color = Accent, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun WalletCard(wallet: Wallet) {
    Card(colors = CardDefaults.cardColors(containerColor = Card), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(wallet.type.uppercase(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(Modifier.height(8.dp))
            wallet.balances.forEach { (currency, bal) ->
                Text("$currency  ${bal.balance}", color = Color.Gray, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun ConnectionDialog(
    initialBaseUrl: String,
    initialAppId: String,
    initialToken: String,
    onDismiss: () -> Unit,
    onSave: (String, String, String) -> Unit,
    onDisconnect: () -> Unit
) {
    var baseUrl by remember { mutableStateOf(initialBaseUrl) }
    var appId by remember { mutableStateOf(initialAppId) }
    var token by remember { mutableStateOf(initialToken) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Card,
        title = { Text("Connect to Deriv", color = Color.White) },
        text = {
            Column {
                OutlinedTextField(baseUrl, { baseUrl = it }, label = { Text("API base URL") }, placeholder = { Text("https://api.deriv.com/") })
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(appId, { appId = it }, label = { Text("Deriv-App-ID") })
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(token, { token = it }, label = { Text("Access token") })
                Spacer(Modifier.height(6.dp))
                Text(
                    "Get an App ID and OAuth token from your Deriv developer account. Stored locally on this device only.",
                    color = Color.Gray, fontSize = 11.sp
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { if (baseUrl.isNotBlank() && appId.isNotBlank() && token.isNotBlank()) onSave(baseUrl, appId, token) }) {
                Text("SAVE & CONNECT", color = Accent)
            }
        },
        dismissButton = {
            Row {
                TextButton(onClick = onDisconnect) { Text("DISCONNECT", color = Color(0xFFE05252)) }
                TextButton(onClick = onDismiss) { Text("CANCEL") }
            }
        }
    )
}
@Composable fun AddEADialog(close:()->Unit, save:(String,String)->Unit) {
    var name by remember { mutableStateOf("") }; var platform by remember { mutableStateOf("MT5") }
    AlertDialog(onDismissRequest=close,containerColor=Card,title={Text("Add Expert Advisor",color=Color.White)},text={
        Column { OutlinedTextField(name,{name=it},label={Text("EA name")}); Spacer(Modifier.height(10.dp)); Text("Platform",color=Color.Gray); Row { listOf("MT5","MT4").forEach { p -> FilterChip(selected=platform==p,onClick={platform=p},label={Text(p)},modifier=Modifier.padding(end=8.dp)) } } }
    },confirmButton={TextButton(onClick={if(name.isNotBlank())save(name,platform)}){Text("ADD",color=Accent)}},dismissButton={TextButton(onClick=close){Text("CANCEL")}})
}

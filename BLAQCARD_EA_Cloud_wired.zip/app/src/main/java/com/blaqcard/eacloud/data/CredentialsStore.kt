package com.blaqcard.eacloud.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.blaqcard.eacloud.network.DerivCredentials
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "blaqcard_deriv_credentials")

/**
 * Persists the connection details the Account screen needs to call the
 * Deriv REST API: the API base URL, the app's Deriv-App-ID, and the user's
 * OAuth bearer token (see components/securitySchemes/oauth2 in
 * schemas/rest-api-openapi.json — token comes from Deriv's own OAuth flow,
 * this app does not mint it).
 *
 * NOTE (prototype-only): values are stored in plain DataStore preferences,
 * not EncryptedSharedPreferences/Keystore. That's fine for local
 * experimentation but the auth token should move to encrypted storage
 * before this ships with a real account attached.
 */
class CredentialsStore(private val context: Context) {

    private object Keys {
        val BASE_URL = stringPreferencesKey("base_url")
        val APP_ID = stringPreferencesKey("app_id")
        val AUTH_TOKEN = stringPreferencesKey("auth_token")
    }

    val credentialsFlow = context.dataStore.data.map { prefs ->
        DerivCredentials(
            baseUrl = prefs[Keys.BASE_URL] ?: "",
            appId = prefs[Keys.APP_ID],
            authToken = prefs[Keys.AUTH_TOKEN]
        )
    }

    suspend fun current(): DerivCredentials = credentialsFlow.first()

    suspend fun save(baseUrl: String, appId: String, authToken: String) {
        context.dataStore.edit { prefs ->
            prefs[Keys.BASE_URL] = baseUrl.trim()
            prefs[Keys.APP_ID] = appId.trim()
            prefs[Keys.AUTH_TOKEN] = authToken.trim()
        }
    }

    suspend fun clear() {
        context.dataStore.edit { it.clear() }
    }
}

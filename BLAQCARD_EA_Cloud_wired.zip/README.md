# BLAQCARD EA Cloud — Android Prototype

This is a first working UI prototype. It is intentionally local/demo-only:
- Dashboard
- EA list
- Start/stop state simulation
- VPS status screen
- Account screen
- Add EA dialog
- Dark BLAQCARD branding

It does NOT yet connect to real MT4/MT5 terminals, brokers, VPS machines, payments, or a backend.

## Build
Open this folder in Android Studio (Ladybug or newer), let Gradle sync, then Run.

If you have a Gradle wrapper installed locally, you can generate/build an APK with:
`./gradlew assembleDebug`

The resulting debug APK is normally:
`app/build/outputs/apk/debug/app-debug.apk`

## Production V2
Next components:
1. Backend API + PostgreSQL
2. Authentication
3. Windows VPS provisioning
4. MT4/MT5 terminal manager/agent
5. Secure EA upload/storage
6. WebSocket live status
7. Billing/subscriptions
8. Push notifications
9. Admin panel

## Deriv API wiring (this update)

The **Account tab** is now wired to Deriv's real REST API (see `schemas/rest-api-openapi.json`):
- `GET /trading/v1/options/accounts` — trading accounts + balances
- `GET /wallet/v1/wallets` — wallet balances
- `GET /account/v1/nickname` — display name

New files:
- `network/DerivModels.kt` — Kotlin models generated from the JSON Schemas
- `network/DerivApi.kt` — Retrofit interface
- `network/NetworkModule.kt` — OkHttp/Retrofit client + auth header injection
- `data/CredentialsStore.kt` — persists base URL / App ID / access token (DataStore, plaintext — prototype only)
- `data/DerivRepository.kt` — fetches + error-maps the three calls above
- `ui/AccountViewModel.kt`, `ui/AccountViewModelFactory.kt` — screen state

Tap **Account → EDIT / CONNECT** in the app and enter your Deriv API base URL, App ID, and an OAuth access token to see real data.

**Not wired (by design):** EA start/stop/list and the VPS screen stay local mock state. Deriv's `auto_start`/`auto_stop` endpoints control Deriv's own synthetic-strategy runs, not real MT4/MT5 Expert Advisors — hooking up real EA control needs a separate MT4/5 bridge (e.g. an MT5 Manager API or MetaApi-style agent), which isn't in schemas.zip.
